#!/usr/bin/python
from bottle import route, run, request
import datetime
import subprocess as sp


def json_friendly(obj):
    if not obj or type(obj) in (int, float, str, unicode, bool, long):
        return obj
    if type(obj) == datetime.datetime:
        return obj.strftime('%Y-%m-%dT%H:%M:%S')
    if type(obj) == dict:
        for k in obj:
            obj[k] = json_friendly(obj[k])
        return obj
    if type(obj) == list:
        for i, v in enumerate(obj):
            obj[i] = json_friendly(v)
        return obj
    if type(obj) == tuple:
        temp = []
        for v in obj:
            temp.append(json_friendly(v))
        return tuple(temp)
    return str(obj)


@route('/detect', method='POST')
def upload_file():
  try:
    print "Got request"
    my_file = request.files.get("image")
    txt = my_file.file.read()
    filename = "detect_" + my_file.filename
    f = open(filename, "w+")
    f.write(txt)
    f.close()
    cmd = ["./darknet", "detect", "cfg/yolov3.cfg" ,"yolov3.weights", filename]
    p = sp.Popen(cmd, stdout=sp.PIPE)
    out = p.stdout.read()
    print out
    return json_friendly({"result":out})
  except Exception, ex:
    print str(ex)


if __name__ == '__main__':
    run(host="0.0.0.0", port=5050, server='twisted')
